---@enum Inky.PointerMode
local PointerMode = {
	POSITION = "POSITION",
	TARGET   = "TARGET",
}

return PointerMode

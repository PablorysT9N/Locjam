return {
  {
    {
      name = "Ruote1",
      x = 2,
      y = 24,
      w = 164,
      h = 22,
      orig_w = 240,
      orig_h = 135,
      offset_x = 32,
      offset_y = 97
    },
    {
      name = "Ruote2",
      x = 168,
      y = 24,
      w = 164,
      h = 22,
      orig_w = 240,
      orig_h = 135,
      offset_x = 32,
      offset_y = 97
    },
    {
      name = "coin",
      x = 180,
      y = 12,
      w = 4,
      h = 4,
      orig_w = 240,
      orig_h = 135,
      offset_x = 26,
      offset_y = 60
    },
    {
      name = "drawer_closed",
      x = 171,
      y = 13,
      w = 7,
      h = 9,
      orig_w = 240,
      orig_h = 135,
      offset_x = 214,
      offset_y = 80
    },
    {
      name = "drawer_open",
      x = 171,
      y = 2,
      w = 7,
      h = 9,
      orig_w = 240,
      orig_h = 135,
      offset_x = 214,
      offset_y = 80
    },
    {
      name = "foreground",
      x = 2,
      y = 3,
      w = 167,
      h = 19,
      orig_w = 240,
      orig_h = 135,
      offset_x = 31,
      offset_y = 92
    },
    {
      name = "laser",
      x = 374,
      y = 58,
      w = 8,
      h = 81,
      orig_w = 240,
      orig_h = 135,
      offset_x = 81,
      offset_y = 26
    },
    {
      name = "laser_side",
      x = 384,
      y = 56,
      w = 3,
      h = 83,
      orig_w = 240,
      orig_h = 135,
      offset_x = 78,
      offset_y = 24
    },
    {
      name = "lights",
      x = 222,
      y = 83,
      w = 150,
      h = 56,
      orig_w = 240,
      orig_h = 135,
      offset_x = 39,
      offset_y = 30
    },
    {
      name = "navigator",
      x = 180,
      y = 18,
      w = 9,
      h = 4,
      orig_w = 240,
      orig_h = 135,
      offset_x = 178,
      offset_y = 79
    },
    {
      name = "van",
      x = 2,
      y = 48,
      w = 218,
      h = 91,
      orig_w = 240,
      orig_h = 135,
      offset_x = 9,
      offset_y = 20
    },
    filename = "room_future.png"
  }
}
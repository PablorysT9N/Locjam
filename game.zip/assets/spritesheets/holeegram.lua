return {
  {
    {
      name = "stand0",
      x = 2,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk0",
      x = 25,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk1",
      x = 25,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk2",
      x = 48,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk3",
      x = 71,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk4",
      x = 71,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk5",
      x = 48,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk6",
      x = 2,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    {
      name = "talk7",
      x = 2,
      y = 2,
      w = 21,
      h = 32,
      orig_w = 23,
      orig_h = 38,
      offset_x = 1,
      offset_y = 3
    },
    filename = "holeegram.png"
  }
}